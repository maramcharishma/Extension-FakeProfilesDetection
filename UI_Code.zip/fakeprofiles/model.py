import sys
import csv
import numpy as np
import pandas as pd
from sklearn.model_selection import cross_validate
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn import preprocessing
from sklearn.metrics import roc_curve, auc
from  sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import learning_curve    
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.svm import SVC
import pickle

def read_datasets():
    genuine_users = pd.read_csv("C:\\Users\\Rachel Reddy\\fakeprofiles\\users.csv")
    fake_users = pd.read_csv("C:\\Users\Rachel Reddy\\fakeprofiles\\fusers.csv")
    x=pd.concat([genuine_users,fake_users])   
    y=len(genuine_users)*[1]+len(fake_users)*[0]
    return x,y
x,y=read_datasets()
# print(x,y)

x = x[[
    "statuses_count",
    "followers_count",
    "friends_count",
    "favourites_count",
    "listed_count","Reported_count"       ]]
# print(x.columns)
# print(y)
# print(x.describe())

x_train,x_test,y_train,y_test = train_test_split(x, y, test_size=0.30, random_state=44)
clf=RandomForestClassifier(n_estimators=40,oob_score=True)
clf.fit(x_train,y_train)
# y_pred = clf.predict(x_test)
# print(y_test,y_pred)


pickle.dump(clf,open("model.pkl","wb"))