from flask import Flask,render_template,request
import pickle
import numpy as np
app=Flask(__name__)
model=pickle.load(open("model.pkl","rb"))
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/',methods=['POST'])
def predict():
    f_features=[x for x in request.form.values()]
    f_features.remove(f_features[0]);
    print(f_features)
    features=[np.array(f_features)]
    prediction=model.predict(features)
    print(prediction)
    flag="Real Account"
    if(prediction[0]==0):
        flag="Fake Account"
    return render_template("index.html",predict=flag)
if __name__=="__main__":
    app.run(debug=True)
